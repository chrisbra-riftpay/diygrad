import pyopencl as cl

print("Hello World")